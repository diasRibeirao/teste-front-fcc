<template>
    <section class="login">
        <h1>Login</h1>
        <form autocomplete="off">
            <Label for="usuario">Usuário</Label>
            <input type="text" name="usuario" id="usuario" v-model="login.usuario"/>

            <Label for="senha">Senha</Label>
            <input type="password" name="senha" id="senha" v-model="login.senha"/>

            <button class="btn" @click.prevent="logar">Logar</button>
        </form>
    </section>
</template>

<script>
export default {
    data() {
        return {
            login: {
                usuario: "",
                senha: ""
            }
        }
    },
    methods: {
        logar() {
            this.$store.commit('UPDATE_LOGIN', true);
        }
    }
}
</script>

<style scoped>
.login {
  max-width: 500px;
  margin: 0 auto;
  padding: 0 20px;
}

h1 {
  text-align: center;
  font-size: 2rem;
  margin-top: 40px;
  color: #87f;
}

form {
  display: grid;
}

.btn {
  width: 100%;
  max-width: 300px;
  margin-left: auto;
  margin-right: auto;
}
</style>