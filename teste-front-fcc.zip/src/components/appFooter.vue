<template>
    <footer>
        <p>Teste para frontend para Fundação Carlos Chagas - FCC</p>
    </footer>
</template>

<script>
export default {
    name: 'appFooter'
}
</script>

<style scoped>

footer {
    background: #87f;
    padding: 25px 0;
    text-align: center;
    font-size: 1.2rem;
    color: #fff;
    position: relative;
}

</style>